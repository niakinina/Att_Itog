package com.example.att_itog.enumm;

public enum Status {
    Принят, Оформлен, Ожидает, Получен
}
